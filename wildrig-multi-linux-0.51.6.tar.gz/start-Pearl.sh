#!/bin/bash

while true
do
./wildrig-multi --algo pearlhash --url pool.pearlhash.xyz:9000 --user prl1p50ltku2jjcwdxh4nzjrw98nwdswdn25qdkr2fdtw8hsq3qu9cdhscchnnm --worker test
sleep 5
done
